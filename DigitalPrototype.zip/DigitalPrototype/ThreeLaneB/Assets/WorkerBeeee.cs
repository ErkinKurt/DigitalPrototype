﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorkerBeeee : MonoBehaviour
{
	private bool _flag = false;

	private Transform _initPlace;
	public Transform _destination;

	public void Move(Transform init,Transform dest)
	{
		Debug.Log("Move is called s " + gameObject.name);
		_initPlace = init;
		_destination = dest;
		_flag = true;
	}
		
	// Update is called once per frame
	void Update () {
		if (_flag)
		{
			Debug.Log("Moving from " + _initPlace.position +"Moving to " + _destination.position);
			transform.position =  Vector2.MoveTowards(transform.position, _destination.position, 10f * Time.deltaTime);
		}
	}
}
